# iStudent React - Redesigned UI (RTL, Modern, Easy to Use)

This package contains drop-in replacements for your existing app's UI shell and several pages.
It keeps your data utilities (src/api.js, src/fetchJSON.js, src/slug.js) and replaces the layout and visuals.

## What's inside
- src/App.jsx - new router layout + clean transitions
- src/components/Layout.jsx - sticky header, responsive sidebar, quick host switch
- src/components/Header.jsx - lightweight header for simple pages
- src/components/Card.jsx - clean card component
- src/pages/Dashboard.jsx - modern landing with quick actions
- src/pages/subjects/SubjectsHub.jsx - revamped subjects hub
- src/pages/resources/Gallery.jsx - improved gallery with better overflow behavior
- src/styles/index.css - minor additions (keeps Tailwind utilities intact)

Tip: Back up your current files, then copy these over your project.
All components are RTL-first and mobile-friendly.

## Install
No new libs required beyond your current React/Tailwind setup.
If you use Vite, run npm run dev as usual.
