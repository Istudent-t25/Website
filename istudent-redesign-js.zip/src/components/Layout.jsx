import React, { useState } from 'react'
import { NavLink, Outlet, Link } from 'react-router-dom'
import { getHost, setHost } from '@/lib/host'

const NAV = [
  { to: '/', label: 'سەرەکی', icon: '🏠' },
  { to: '/subjects', label: 'بابەتەکان', icon: '📚' },
  { to: '/resources/gallery', label: 'وێنەخانە', icon: '🖼️' },
]

export default function Layout() {
  const [open, setOpen] = useState(false)
  const [host, setHostState] = useState(getHost())

  const saveHost = () => { if (host) setHost(host) }

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-[260px_1fr] bg-zinc-950 text-zinc-100">
      {/* Sidebar */}
      <aside className={"bg-zinc-900/70 border-l border-white/10 " + (open ? '' : 'hidden lg:block')}>
        <div className="p-4 flex items-center justify-between gap-2 border-b border-white/10">
          <Link to="/" className="text-cyan-300 font-bold text-xl">iStudent</Link>
          <button className="lg:hidden px-3 py-2 rounded-xl bg-white/5" onClick={()=>setOpen(false)}>✕</button>
        </div>
        <nav className="p-2 space-y-1">
          {NAV.map(i => (
            <NavLink
              key={i.to}
              to={i.to}
              end
              className={({isActive}) =>
                'block rounded-xl px-3 py-2 hover:bg-white/5 ' +
                (isActive ? 'bg-cyan-500/10 text-cyan-300' : '')
              }
            >
              <span className="ml-2">{i.icon}</span>{i.label}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 mt-2 border-t border-white/10">
          <label className="text-xs text-zinc-400">ناونیشانی API (پۆرت 4000)</label>
          <div className="mt-2 flex gap-2">
            <input className="w-full bg-zinc-800 rounded-lg px-3 py-2 outline-none ltr" value={host} onChange={e=>setHostState(e.target.value)} placeholder="http://192.168.1.5:4000" />
            <button className="px-3 py-2 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30" onClick={saveHost}>پاشەکەوت</button>
          </div>
          <p className="text-xs text-zinc-500 mt-1 ltr">{getHost()}</p>
        </div>
      </aside>

      {/* Main */}
      <main>
        <div className="sticky top-0 z-30 bg-zinc-950/70 backdrop-blur border-b border-white/10">
          <div className="px-3 py-3 flex items-center justify-between gap-2">
            <button className="lg:hidden px-3 py-2 rounded-xl bg-white/5" onClick={()=>setOpen(true)}>≡</button>
            <div className="flex-1" />
            <Link to="/" className="px-3 py-2 rounded-xl bg-white/5">ماڵەوە</Link>
          </div>
        </div>
        <div className="p-4 container mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
