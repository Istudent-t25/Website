import React from 'react'
import clsx from 'clsx'

export default function Card({ className='', children, as:Tag='div', onClick }) {
  return (
    <Tag
      onClick={onClick}
      className={clsx(
        'rounded-2xl bg-zinc-900/60 border border-white/10 shadow-[0_8px_30px_rgb(0,0,0,0.12)]',
        'hover:border-cyan-400/30 transition-colors',
        className
      )}
    >
      {children}
    </Tag>
  )
}
