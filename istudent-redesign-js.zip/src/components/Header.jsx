import React from 'react'

export default function Header({ title, actions=null, subtitle=null }) {
  return (
    <div className="sticky top-0 z-20 bg-zinc-950/70 backdrop-blur border-b border-white/10">
      <div className="container mx-auto px-3 py-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-zinc-100">{title}</h1>
            {subtitle && <p className="text-zinc-400 text-sm mt-0.5">{subtitle}</p>}
          </div>
          <div className="flex items-center gap-2">{actions}</div>
        </div>
      </div>
    </div>
  )
}
