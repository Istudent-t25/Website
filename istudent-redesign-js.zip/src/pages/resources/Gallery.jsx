import React, { useEffect, useState } from 'react'
import Card from '@/components/Card'

export default function Gallery() {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Demo content - replace with your API list if available
    const demo = Array.from({length: 8}).map((_,i)=>({
      id:i+1, url:`https://picsum.photos/seed/${i+11}/1200/800`, title:`وێنە ${i+1}`, desc:'کورتە وەسفێک لەسەر وێنەکە'
    }))
    setItems(demo); setLoading(false)
  }, [])

  if (loading) return <div>ئامادەکردن...</div>

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">وێنەخانە</h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((it) => (
          <Card key={it.id} className="overflow-hidden group">
            <figure className="flex flex-col">
              <div className="relative w-full aspect-[4/3] overflow-hidden">
                {/* Make image fully visible without requiring scroll */}
                <img
                  src={it.url}
                  alt={it.title}
                  className="absolute inset-0 w-full h-full object-contain bg-zinc-950"
                  loading="lazy"
                />
              </div>
              <figcaption className="p-3 border-t border-white/10">
                <div className="font-semibold">{it.title}</div>
                <div className="text-zinc-400 text-sm">{it.desc}</div>
              </figcaption>
            </figure>
          </Card>
        ))}
      </div>
    </div>
  )
}
