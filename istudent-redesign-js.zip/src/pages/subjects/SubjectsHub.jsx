import React, { useMemo } from 'react'
import Card from '@/components/Card'
import { Link } from 'react-router-dom'

const GROUPS = [
  { key:'scientific', title:'زانستی', items:['بیرکاری','فیزیا','کیمیا','زیندەزانی'] },
  { key:'languages', title:'زمان', items:['ئینگلیزی','کوردی','عەرەبی','ئیسلام'] },
  { key:'literary', title:'ئەدەبی', items:['مەرج','جغرافیا','میژوو'] },
]

export default function SubjectsHub() {
  const groups = useMemo(()=>GROUPS,[])

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-3">
        <h2 className="text-xl font-bold">بابەتەکان</h2>
        <div className="text-sm text-zinc-400">ڕێکخستنی گرووپەکان</div>
      </div>

      {groups.map(g => (
        <section key={g.key} className="space-y-3">
          <h3 className="text-lg font-semibold text-cyan-300">{g.title}</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {g.items.map(name => (
              <Card key={name} className="p-4">
                <Link to={`/resources/papers?subject=${encodeURIComponent(name)}`} className="block">
                  <div className="text-xl font-bold">{name}</div>
                  <div className="text-zinc-400 text-sm mt-1">کلیک بکە بۆ سەرچاوەکان</div>
                </Link>
              </Card>
            ))}
          </div>
        </section>
      ))}
    </div>
  )
}
