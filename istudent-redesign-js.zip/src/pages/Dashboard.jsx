import React from 'react'
import Card from '@/components/Card'
import { Link } from 'react-router-dom'

const QUICK = [
  { to: '/subjects', title: 'بابەتەکان', desc: 'هەموو بابەتەکان بە گرووپ', emoji: '📚' },
  { to: '/resources/gallery', title: 'وێنەخانە', desc: 'وێنە و دەقەکان', emoji: '🖼️' },
]

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-zinc-900/60 to-zinc-900/20 p-6">
        <h2 className="text-2xl font-bold">چێژبوونەوە بۆ iStudent</h2>
        <p className="text-zinc-400 mt-1">ئاسان، خێرا، رەهەنددار. هەموو شتێک لێرەیە.</p>
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {QUICK.map((q) => (
            <Card key={q.to} className="p-4 hover:translate-y-[-2px] transition-transform">
              <Link to={q.to} className="block">
                <div className="text-3xl">{q.emoji}</div>
                <div className="mt-2 font-bold">{q.title}</div>
                <div className="text-zinc-400 text-sm">{q.desc}</div>
              </Link>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
