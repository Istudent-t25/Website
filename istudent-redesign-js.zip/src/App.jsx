import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Layout from '@/components/Layout'
import Dashboard from '@/pages/Dashboard'
import SubjectsHub from '@/pages/subjects/SubjectsHub'
import Gallery from '@/pages/resources/Gallery'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout/>}>
        <Route index element={<Dashboard/>} />
        <Route path="/subjects" element={<SubjectsHub/>} />
        <Route path="/resources/gallery" element={<Gallery/>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  )
}
