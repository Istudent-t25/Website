import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  LibraryBig,
  Search,
  Loader2,
  Sparkles,
  CheckCircle2,
  Info,
} from "lucide-react";

/** APIs */
const API_SUBJECTS = "https://api.studentkrd.com/api/v1/subjects";
const API_DOCS = "https://api.studentkrd.com/api/v1/documents";
const API_PAPERS = "https://api.studentkrd.com/api/v1/papers";

/** utils */
async function fetchJSON(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error("Network error");
  return r.json();
}

/** fetch all pages helper (follows next_page_url) */
async function fetchAllPages(baseUrl, initialParams = "") {
  const out = [];
  let url = `${baseUrl}${initialParams ? `?${initialParams}` : ""}`;
  let guard = 0;
  while (url && guard < 20) {
    // cap pages to avoid accidental loops
    const j = await fetchJSON(url);
    if (Array.isArray(j?.data)) out.push(...j.data);
    url = j?.next_page_url || null;
    guard += 1;
  }
  return out;
}

/** localStorage -> stream key */
function normalizeTrack(v) {
  const t = (v || "").toLowerCase();
  if (t.includes("scientific") || t.includes("sci") || t === "زانستی") return "scientific";
  if (t.includes("literary") || t.includes("lit") || t === "ئەدەبی") return "literary";
  if (t.includes("both") || t === "هاوبەش") return "both";
  return null;
}
function streamKurdish(s) {
  if (s === "scientific") return "زانستی";
  if (s === "literary") return "ئەدەبی";
  if (s === "both") return "هاوبەش";
  return "—";
}

const Section = ({ title, count, children, icon }) => (
  <div className="space-y-2">
    <div className="flex items-center gap-2 text-white">
      {icon || <Sparkles className="w-4 h-4 text-emerald-300" />}
      <div className="font-extrabold">{title}</div>
      <span className="text-[11px] text-zinc-300">({count})</span>
    </div>
    {children}
  </div>
);

const Card = ({ subject, onClick, badge }) => (
  <button
    onClick={() => onClick(subject.id)}
    className="group text-right rounded-2xl p-3 bg-zinc-900/60 border border-white/10 hover:bg-zinc-900/80 transition w-full"
    title={subject.name}
  >
    <div className="flex items-start justify-between gap-2">
      <div className="text-[13px] font-bold text-white line-clamp-2">{subject.name}</div>
      {badge && (
        <span className="shrink-0 px-2 py-0.5 rounded-full text-[10px] bg-white/5 border border-white/10 text-zinc-100">
          {badge}
        </span>
      )}
    </div>
    <div className="mt-1 flex items-center gap-1 text-[11px] text-zinc-400">
      <CheckCircle2 className="w-3.5 h-3.5" />
      <span>ئامادەیە</span>
    </div>
  </button>
);

const SkeletonGrid = ({ rows = 8 }) => (
  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
    {Array.from({ length: rows }).map((_, i) => (
      <div
        key={i}
        className="rounded-2xl h-16 bg-zinc-900/60 border border-white/10 overflow-hidden relative"
      >
        <div className="absolute inset-0 animate-pulse bg-gradient-to-r from-transparent via-white/5 to-transparent" />
      </div>
    ))}
  </div>
);

export default function SubjectsHub() {
  const nav = useNavigate();

  const [grade, setGrade] = useState(null); // number | null
  const [track, setTrack] = useState(null); // "scientific" | "literary" | "both" | null

  const [allSubjects, setAllSubjects] = useState([]); // {id,name,code}
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");

  // availability sets
  const [avail, setAvail] = useState({
    any: new Set(),       // any content for selected grade (and track when >=10)
    scientific: new Set(),
    literary: new Set(),
    both: new Set(),
    basic: new Set(),     // null stream / lower grades
  });

  useEffect(() => {
    // read grade/track from localStorage
    try {
      const gRaw = localStorage.getItem("grade");
      const tRaw = localStorage.getItem("track");
      const g = gRaw ? Number(gRaw) : null;
      setGrade(Number.isFinite(g) ? g : null);
      setTrack(normalizeTrack(tRaw));
    } catch {
      setGrade(null);
      setTrack(null);
    }
  }, []);

  useEffect(() => {
    let ok = true;

    (async () => {
      setLoading(true);
      try {
        // 1) subjects
        const subjectsJSON = await fetchJSON(`${API_SUBJECTS}?page=1&per_page=100`);
        const subjects = (subjectsJSON?.data || []).map(s => ({
          id: s.id,
          name: s.name,
          code: (s.code || "").toLowerCase() || null, // "scientific"|"literary"|"both"|null
        }));
        if (!ok) return;
        setAllSubjects(subjects);

        // 2) availability: scan documents + papers
        // build params based on grade and track (for >=10, use specific stream; for <=9, ignore stream)
        const wantsStream = typeof grade === "number" && grade >= 10;
        const commonParams = new URLSearchParams();
        if (typeof grade === "number" && !Number.isNaN(grade)) commonParams.set("grade", String(grade));
        if (wantsStream && track) commonParams.set("stream", track);
        commonParams.set("per_page", "100");

        // documents: subject_id & stream live on item level
        const docs = await fetchAllPages(API_DOCS, commonParams.toString());

        // papers: subject_id & stream live on top-level entry
        // we want all types: important_note, important_questions, national_exam, images_of_sessions
        const papers = await fetchAllPages(API_PAPERS, commonParams.toString());

        const sets = {
          any: new Set(),
          scientific: new Set(),
          literary: new Set(),
          both: new Set(),
          basic: new Set(),
        };

        // fold docs
        for (const d of docs) {
          const sid = d?.subject_id;
          if (!sid) continue;
          sets.any.add(sid);
          const st = (d?.stream || null) ? String(d.stream).toLowerCase() : null;
          if (st === "scientific") sets.scientific.add(sid);
          else if (st === "literary") sets.literary.add(sid);
          else if (st === "both") sets.both.add(sid);
          else sets.basic.add(sid);
        }
        // fold papers
        for (const p of papers) {
          const sid = p?.subject_id;
          if (!sid) continue;
          sets.any.add(sid);
          const st = (p?.stream || null) ? String(p.stream).toLowerCase() : null;
          if (st === "scientific") sets.scientific.add(sid);
          else if (st === "literary") sets.literary.add(sid);
          else if (st === "both") sets.both.add(sid);
          else sets.basic.add(sid);
        }

        if (!ok) return;
        setAvail(sets);
      } catch (e) {
        if (!ok) return;
        // on error, show nothing but keep app usable
        setAvail({
          any: new Set(),
          scientific: new Set(),
          literary: new Set(),
          both: new Set(),
          basic: new Set(),
        });
      } finally {
        if (ok) setLoading(false);
      }
    })();

    return () => {
      ok = false;
    };
  }, [grade, track]);

  /** search filter */
  const queryFiltered = useMemo(() => {
    if (!q.trim()) return allSubjects;
    const needle = q.trim().toLowerCase();
    return allSubjects.filter((s) => (s.name || "").toLowerCase().includes(needle));
  }, [q, allSubjects]);

  /** group into sections based on grade logic */
  const grouped = useMemo(() => {
    const wantsStream = typeof grade === "number" && grade >= 10;

    if (!wantsStream) {
      // grades ≤ 9 -> only subjects without a code (basic curriculum)
      const basic = queryFiltered.filter(
        (s) => !s.code && avail.basic.has(s.id)
      );
      return { mode: "basic", basic };
    }

    // grades ≥ 10 -> show three sections, but only those with availability in each
    const sci = queryFiltered.filter(
      (s) => s.code === "scientific" && (avail.scientific.has(s.id) || avail.both.has(s.id))
    );
    const both = queryFiltered.filter(
      (s) => s.code === "both" && (avail.both.has(s.id) || avail.scientific.has(s.id) || avail.literary.has(s.id))
    );
    const lit = queryFiltered.filter(
      (s) => s.code === "literary" && (avail.literary.has(s.id) || avail.both.has(s.id))
    );
    return { mode: "tracks", sci, both, lit };
  }, [queryFiltered, avail, grade]);

  /** navigation */
  const openSubject = (id) => {
    // pass through: subject details will again read grade/track from localStorage
    const url = `/subjects/${id}`;
    // scroll restore friendly
    window.location.assign(url);
  };

  return (
    <div dir="rtl" className="p-3 sm:p-5 space-y-4">
      {/* header */}
      <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-emerald-500/10 to-emerald-400/5 p-3 sm:p-4 sticky top-2 z-10">
        <div className="flex items-center gap-2 text-white">
          <LibraryBig className="w-5 h-5 text-emerald-300" />
          <div className="font-extrabold text-lg sm:text-xl">بابەتەکان</div>
          {typeof grade === "number" && (
            <span className="text-[11px] text-zinc-300 mr-2">
              پۆل: <b className="text-white">{grade}</b>
            </span>
          )}
          {grade >= 10 && (
            <span className="text-[11px] text-zinc-300">
              تڕاک: <b className="text-white">{streamKurdish(track)}</b>
            </span>
          )}
        </div>

        <div className="mt-3 relative">
          <input
            dir="rtl"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="گەڕان بۆ ناوی بابەت..."
            className="w-full rounded-2xl bg-zinc-900/60 border border-white/10 text-white text-sm px-10 py-2.5 outline-none focus:ring-2 focus:ring-emerald-400/30"
          />
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
          <div className="mt-2 text-[11px] text-zinc-400 flex items-center gap-1">
            <Info className="w-3.5 h-3.5" />
            <span>تەنها ئەو بابەتانە پیشان دەدرێن کە بۆ پۆلی هەڵبژێردراوت خواردنی ناوەوە هەبن.</span>
          </div>
        </div>
      </div>

      {/* body */}
      {loading ? (
        <SkeletonGrid rows={12} />
      ) : grouped.mode === "basic" ? (
        <>
          <Section
            title="بابەتە بنەڕهتییەکان"
            count={grouped.basic.length}
            icon={<Sparkles className="w-4 h-4 text-sky-300" />}
          >
            {grouped.basic.length === 0 ? (
              <div className="text-zinc-400 text-sm">هیچ بابەتێک نەدۆزرایەوە.</div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
                {grouped.basic.map((s) => (
                  <Card key={s.id} subject={s} onClick={openSubject} badge="بەناوەند" />
                ))}
              </div>
            )}
          </Section>
        </>
      ) : (
        <div className="space-y-5">
          <Section title="زانستی" count={grouped.sci.length}>
            {grouped.sci.length === 0 ? (
              <div className="text-zinc-400 text-sm">نییە.</div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
                {grouped.sci.map((s) => (
                  <Card key={s.id} subject={s} onClick={openSubject} badge="زانستی" />
                ))}
              </div>
            )}
          </Section>

          <Section title="هاوبەش" count={grouped.both.length}>
            {grouped.both.length === 0 ? (
              <div className="text-zinc-400 text-sm">نییە.</div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
                {grouped.both.map((s) => (
                  <Card key={s.id} subject={s} onClick={openSubject} badge="هاوبەش" />
                ))}
              </div>
            )}
          </Section>

          <Section title="ئەدەبی" count={grouped.lit.length}>
            {grouped.lit.length === 0 ? (
              <div className="text-zinc-400 text-sm">نییە.</div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
                {grouped.lit.map((s) => (
                  <Card key={s.id} subject={s} onClick={openSubject} badge="ئەدەبی" />
                ))}
              </div>
            )}
          </Section>
        </div>
      )}
    </div>
  );
}
