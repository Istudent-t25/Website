// src/pages/Viewer.jsx
import React, { useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ZoomIn, ZoomOut, RotateCcw, AlertTriangle } from "lucide-react";

/* ---------- helpers ---------- */
function getExt(u) {
  try { return new URL(u).pathname.split(".").pop()?.toLowerCase() || ""; }
  catch { return String(u).split("?")[0].split(".").pop()?.toLowerCase() || ""; }
}
const isPDF   = (u) => getExt(u) === "pdf";
const isImage = (u) => /^(png|jpg|jpeg|gif|webp|bmp|tiff|svg)$/i.test(getExt(u));
const isVideo = (u) => /^(mp4|webm|mov|mkv|m4v|m3u8|ts)$/i.test(getExt(u));

export default function Viewer() {
  const location = useLocation();
  const navigate = useNavigate();
  const sp = useMemo(() => new URLSearchParams(location.search), [location.search]);

  // Source & meta coming from /viewer?u=...&t=...&type=...
  const src   = sp.get("u") || "";
  const title = sp.get("t") || "Viewer";
  const kind  = sp.get("type") || (isPDF(src) ? "pdf" : isImage(src) ? "image" : isVideo(src) ? "video" : "file");

  const [zoom, setZoom] = useState(1);
  const [err, setErr] = useState("");
  const imgRef = useRef(null);

  const zoomIn  = () => setZoom((z) => Math.min(5, Math.round((z + 0.1) * 10) / 10));
  const zoomOut = () => setZoom((z) => Math.max(0.2, Math.round((z - 0.1) * 10) / 10));
  const reset   = () => setZoom(1);

  // Fallback if nothing to show
  if (!src) {
    return (
      <div className="h-screen w-full grid place-items-center bg-zinc-950 text-zinc-300">
        <div className="text-center">
          <AlertTriangle className="w-8 h-8 mx-auto mb-3 text-amber-400" />
          <div className="text-lg font-semibold">هیچ فایلی نییه بۆ بینین</div>
          <div className="text-sm mt-1 opacity-80">پارامەتەری <code>u</code> نییە لە URL ـەکە.</div>
          <button onClick={() => navigate(-1)} className="mt-4 px-3 py-1.5 rounded-lg bg-white/10 ring-1 ring-white/10">
            گەڕانەوە
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-full flex flex-col bg-zinc-950 text-zinc-100" dir="rtl">
      {/* Top bar */}
      <div className="shrink-0 px-3 sm:px-4 py-2 border-b border-white/10 bg-zinc-950/80 backdrop-blur supports-[backdrop-filter]:bg-zinc-950/60">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button onClick={() => navigate(-1)} className="px-2 py-1 rounded-lg bg-white/5 ring-1 ring-white/10 text-sm">
              گەڕانەوە
            </button>
          </div>
          <div className="min-w-0 text-center">
            <div className="truncate font-semibold">{title}</div>
            <div className="text-[11px] text-zinc-400">{kind.toUpperCase()}</div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={zoomOut} className="p-2 rounded-lg bg-white/5 ring-1 ring-white/10"><ZoomOut className="w-4 h-4" /></button>
            <div className="px-2 text-sm tabular-nums">{Math.round(zoom * 100)}%</div>
            <button onClick={zoomIn} className="p-2 rounded-lg bg-white/5 ring-1 ring-white/10"><ZoomIn className="w-4 h-4" /></button>
            <button onClick={reset} className="p-2 rounded-lg bg-white/5 ring-1 ring-white/10"><RotateCcw className="w-4 h-4" /></button>
          </div>
        </div>
      </div>

      {/* Stage (flex child that CAN shrink/scroll) */}
      <div className="flex-1 min-h-0 grid place-items-center overflow-hidden">
        {/* Scroll container MUST have min-w-0/min-h-0 */}
        <div className="min-w-0 min-h-0 max-w-[95vw] max-h-[82vh] overflow-auto bg-[linear-gradient(45deg,rgba(255,255,255,.05)_25%,transparent_25%),linear-gradient(-45deg,rgba(255,255,255,.05)_25%,transparent_25%),linear-gradient(45deg,transparent_75%,rgba(255,255,255,.05)_75%),linear-gradient(-45deg,transparent_75%,rgba(255,255,255,.05)_75%)] bg-[length:20px_20px] bg-[position:0_0,0_10px,10px_-10px,-10px_0] rounded-xl">
          {kind === "image" && !err && (
            <img
              ref={imgRef}
              src={src}
              alt={title}
              onError={() => setErr("نەتوانرا وێنە باربکرێت.")}
              style={{ width: `${zoom * 100}%`, height: "auto" }}  /* width-based zoom */
              className="block mx-auto select-none"
              draggable={false}
            />
          )}

          {kind === "pdf" && (
            <iframe
              title={title}
              src={src}
              className="block w-[95vw] h-[82vh] rounded-xl"
            />
          )}

          {kind === "video" && (
            <video src={src} controls className="block w-[95vw] max-h-[82vh] rounded-xl" />
          )}

          {kind !== "image" && kind !== "pdf" && kind !== "video" && (
            <a href={src} target="_blank" rel="noopener noreferrer" className="inline-block m-4 px-3 py-2 rounded-lg bg-white/10 ring-1 ring-white/10">
              کردنەوەی فایل
            </a>
          )}

          {err && (
            <div className="p-4 text-sm text-red-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" /> {err}
            </div>
          )}
        </div>
      </div>

      {/* Meta footer (always visible) */}
      <div className="shrink-0 w-full px-3 sm:px-4 py-3 border-t border-white/10 bg-zinc-950/80 backdrop-blur supports-[backdrop-filter]:bg-zinc-950/60">
        <div className="text-[12px] text-zinc-300">
          <span className="px-2 py-1 rounded-lg bg-white/5 ring-1 ring-white/10">ناونیشان: {title}</span>
          {isImage(src) && <span className="ml-2 px-2 py-1 rounded-lg bg-white/5 ring-1 ring-white/10">وێنە</span>}
          {isPDF(src)   && <span className="ml-2 px-2 py-1 rounded-lg bg-white/5 ring-1 ring-white/10">PDF</span>}
          {isVideo(src) && <span className="ml-2 px-2 py-1 rounded-lg bg-white/5 ring-1 ring-white/10">ڤیدیۆ</span>}
        </div>
      </div>
    </div>
  );
}
