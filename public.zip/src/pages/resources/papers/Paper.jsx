// src/pages/Paper.jsx
import React, { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  FileText,
  FileCheck2,
  Image as ImageIcon,
  GraduationCap,
  ClipboardList,
  Layers,
  Loader2,
  Search,
  ArrowRightCircle,
  CalendarDays,
  User2,
  BookOpen,
  Download,
} from "lucide-react";

/* =========================
   CONFIG / META
   ========================= */
const API_PAPERS = "https://api.studentkrd.com/api/v1/papers";
const PER_PAGE = 12;

const TYPE_META = {
  national_exam: { title: "ئازمونی نیشتمانی", icon: FileCheck2, tone: "text-cyan-300" },
  important_note: { title: "تێبینی گرنگ", icon: FileText, tone: "text-purple-300" },
  important_questions: { title: "ئەسیلەی گرنگ", icon: ClipboardList, tone: "text-amber-300" },
  worksheet: { title: "ڕاهێنان/کارەکان", icon: Layers, tone: "text-emerald-300" },
  images_of_sessions: { title: "وێنەکانی وانە", icon: ImageIcon, tone: "text-sky-300" },
  bundle: { title: "کۆکردەوە", icon: FileText, tone: "text-zinc-300" },
};

const STREAM_MAP = { scientific: "زانستی", literary: "ئەدەبی", both: "هاوبەش" };

/* =========================
   UTILS
   ========================= */
async function fetchJSON(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error("Network error");
  return r.json();
}
function buildQuery({ subjectId, subject, grade, stream, type, page = 1, perPage = PER_PAGE }) {
  const sp = new URLSearchParams();
  if (type) sp.set("type", type);
  if (subjectId) sp.set("subject_id", subjectId);
  else if (subject) sp.set("subject", subject);
  if (grade) sp.set("grade", grade);
  if (stream) sp.set("stream", stream);
  sp.set("page", String(page));
  sp.set("per_page", String(perPage));
  return `${API_PAPERS}?${sp.toString()}`;
}
function streamLabel(s) {
  return STREAM_MAP[(s || "").toLowerCase()] || s || "";
}
function formatDate(d) {
  if (!d) return null;
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return null;
  const y = dt.getFullYear();
  const m = String(dt.getMonth() + 1).padStart(2, "0");
  const da = String(dt.getDate()).padStart(2, "0");
  return `${y}-${m}-${da}`;
}
function toDl(u) {
  try { return new URL(u).toString(); } catch { return u; }
}

// Normalize/clean URL (basic)
function toCU(u) {
  if (!u) return "";
  try { return new URL(u).toString(); } catch { return String(u).trim(); }
}
function ext(u = "") {
  const m = /[#?]/.test(u) ? u.split(/[?#]/)[0] : u;
  const p = m.split(".").pop();
  return (p || "").toLowerCase();
}
function isPDF(u) { return ext(u) === "pdf"; }
function isImage(u) { return ["png","jpg","jpeg","webp","gif","bmp","svg","avif"].includes(ext(u)); }
function isVideoFile(u) { return ["mp4","m3u8","webm","mov","mkv","avi"].includes(ext(u)); }

/* =========================
   SMALL UI PRIMITIVES
   ========================= */
function Pill({ className = "", children }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg ring-1 text-[11px] ${className}`}>
      {children}
    </span>
  );
}
function YearBadge({ ys, ye }) {
  if (!ys || !ye) return null;
  return <Pill className="bg-white/5 ring-white/10 text-zinc-300">{ys}–{String(ye).slice(-2)}</Pill>;
}
function TermBadge({ t }) {
  if (!t) return null;
  return <Pill className="bg-white/5 ring-white/10 text-zinc-300">خولی {t}</Pill>;
}
function SessionBadge({ s }) {
  if (s === undefined || s === null) return null;
  return <Pill className="bg-white/5 ring-white/10 text-zinc-300">وانە {s}</Pill>;
}
function GradeBadge({ g }) {
  if (!g) return null;
  return (
    <Pill className="bg-white/5 ring-white/10 text-zinc-300">
      <GraduationCap className="w-3 h-3" />
      پۆل {g}
    </Pill>
  );
}
function TrackBadge({ tr }) {
  const lbl = streamLabel(tr);
  if (!lbl) return null;
  return <Pill className="bg-white/5 ring-white/10 text-zinc-300">{lbl}</Pill>;
}
function DateBadge({ d }) {
  const s = formatDate(d);
  if (!s) return null;
  return (
    <Pill className="bg-white/5 ring-white/10 text-zinc-300">
      <CalendarDays className="w-3 h-3" />
      {s}
    </Pill>
  );
}
function LoadingRow() {
  return (
    <div className="rounded-2xl border border-white/10 bg-zinc-900/60 p-2.5 sm:p-3.5">
      <div className="flex items-start gap-2.5 sm:gap-3">
        <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-white/5 animate-pulse" />
        <div className="flex-1 space-y-2">
          <div className="h-4 w-2/3 bg-white/10 rounded animate-pulse" />
          <div className="flex gap-2">
            <div className="h-3 w-24 bg-white/10 rounded animate-pulse" />
            <div className="h-3 w-20 bg-white/10 rounded animate-pulse" />
            <div className="h-3 w-16 bg-white/10 rounded animate-pulse" />
          </div>
        </div>
        <div className="w-20 h-8 bg-white/10 rounded animate-pulse hidden xs:block" />
      </div>
    </div>
  );
}

/* =========================
   LIST ITEM (VERTICAL, RESPONSIVE)
   ========================= */
function ItemRow({ item, onOpen }) {
  const meta = TYPE_META[item.parent_type] || TYPE_META.bundle;
  const TypeIcon = meta.icon || FileText;

  return (
    <div className="rounded-2xl border border-white/10 bg-zinc-900/60 hover:bg-zinc-900/80 p-2.5 sm:p-3.5">
      <div className="flex items-start gap-2.5 sm:gap-3">
        {/* Left: icon */}
        <div className="shrink-0 w-14 h-14 sm:w-16 sm:h-16 rounded-xl grid place-items-center bg-zinc-800/60 ring-1 ring-white/10">
          <TypeIcon size={18} className={meta.tone || "text-zinc-200"} />
        </div>

        {/* Middle: title + meta */}
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 mb-0.5 sm:mb-1">
            <Pill className="bg-white/10 ring-white/20 text-zinc-200">
              {meta.title}
            </Pill>
            {item.subject_name && (
              <Pill className="bg-purple-900/20 ring-purple-800/40 text-purple-300">
                {item.subject_name}
              </Pill>
            )}
            {item.teacher_name && (
              <Pill className="bg-rose-900/20 ring-rose-800/40 text-rose-300">
                <User2 className="w-3 h-3" />
                <span className="line-clamp-1">{item.teacher_name}</span>
              </Pill>
            )}
          </div>

          <h3 className="text-[14.5px] sm:text-[15px] font-bold text-white leading-snug line-clamp-2">
            {item.item_label || item.parent_title || "پەڕە"}
          </h3>

          <div className="mt-1.5 sm:mt-2 flex flex-wrap gap-1.5">
            <YearBadge ys={item.year_start} ye={item.year_end} />
            <TermBadge t={item.term} />
            <SessionBadge s={item.session_no} />
            <DateBadge d={item.date || item.created_at} />
            <GradeBadge g={item.grade} />
            <TrackBadge tr={item.stream} />
          </div>

          {item.parent_title && (
            <div className="mt-1.5 text-[11.5px] text-zinc-400 line-clamp-1">
              لە کۆمەڵەی: {item.parent_title}
            </div>
          )}

          {/* Mobile actions bar (stack under text) */}
          <div className="mt-2 flex gap-2 sm:hidden">
            <button
              onClick={onOpen}
              className="flex-1 px-2.5 py-2 rounded-lg bg-zinc-800/60 ring-1 ring-zinc-700/70 text-zinc-100 text-[12px] hover:bg-zinc-800"
            >
              بینین
            </button>
            {item.url && (
              <a
                href={toDl(item.url)}
                download
                className="px-2.5 py-2 rounded-lg bg-zinc-900/60 ring-1 ring-zinc-700/70 text-zinc-100 text-[12px] hover:bg-zinc-900 inline-flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5 -mt-0.5" /> داگرتن
              </a>
            )}
          </div>
        </div>

        {/* Right: actions (hidden on very small screens) */}
        <div className="shrink-0 hidden sm:flex flex-col items-end gap-2">
          <button
            onClick={onOpen}
            className="px-2.5 py-1.5 rounded-lg bg-zinc-800/60 ring-1 ring-zinc-700/70 text-zinc-100 text-[12px] hover:bg-zinc-800"
          >
            بینین
          </button>
          {item.url && (
            <a
              href={toDl(item.url)}
              download
              className="px-2.5 py-1.5 rounded-lg bg-zinc-900/60 ring-1 ring-zinc-700/70 text-zinc-100 text-[12px] hover:bg-zinc-900 inline-flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5 -mt-0.5" /> داگرتن
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

/* =========================
   PAGE
   ========================= */
export default function Papers() {
  const location = useLocation();
  const navigate = useNavigate();
  const params = useMemo(() => new URLSearchParams(location.search), [location.search]);

  const subjectId = params.get("subject_id") || "";
  const subject = params.get("subject") || "";
  const grade = params.get("grade") || "";
  const stream = params.get("stream") || "";
  const type = params.get("type") || "";

  const [loading, setLoading] = useState(true);
  const [moreLoading, setMoreLoading] = useState(false);
  const [err, setErr] = useState("");
  const [meta, setMeta] = useState({ page: 1, last: 1, total: 0 });

  // raw papers pages (for pagination)
  const [papers, setPapers] = useState([]);
  // flattened item rows
  const [rows, setRows] = useState([]);
  // search
  const [q, setQ] = useState("");

  const backParam = `${location.pathname}${location.search}`;
  const headerTitle = useMemo(() => {
    if (type && TYPE_META[type]) return TYPE_META[type].title;
    return "پەڕەکان";
  }, [type]);

  // fetch page 1 on filter change
  useEffect(() => {
    let ok = true;
    setErr("");
    setLoading(true);
    setPapers([]);
    setRows([]);
    setMeta({ page: 1, last: 1, total: 0 });

    (async () => {
      try {
        const url = buildQuery({ subjectId, subject, grade, stream, type, page: 1, perPage: PER_PAGE });
        const j = await fetchJSON(url);
        if (!ok) return;

        const data = j?.data || [];
        setPapers(data);
        setMeta({
          page: j?.current_page || 1,
          last: j?.last_page || 1,
          total: j?.total || (data.length || 0),
        });

        // flatten items -> rows
        setRows(flattenItems(data));
      } catch {
        if (!ok) return;
        setErr("نەتوانرا پەڕەکان باربکرێن.");
      } finally {
        if (ok) setLoading(false);
      }
    })();

    return () => { ok = false; };
  }, [subjectId, subject, grade, stream, type]);

  const loadMore = async () => {
    if (meta.page >= meta.last || moreLoading) return;
    const next = meta.page + 1;
    setMoreLoading(true);
    try {
      const url = buildQuery({ subjectId, subject, grade, stream, type, page: next, perPage: PER_PAGE });
      const j = await fetchJSON(url);
      const data = j?.data || [];
      setPapers(prev => prev.concat(data));
      setRows(prev => prev.concat(flattenItems(data)));
      setMeta({
        page: j?.current_page || next,
        last: j?.last_page || next,
        total: j?.total || 0,
      });
    } catch {
      setErr("نەتوانرا پەڕەی داهاتوو بکرێت.");
    } finally {
      setMoreLoading(false);
    }
  };

  // client search across flattened items + parent info
  const filtered = useMemo(() => {
    const n = q.trim().toLowerCase();
    if (!n) return rows;
    const match = (s) => (s || "").toString().toLowerCase().includes(n);
    return rows.filter((r) =>
      match(r.item_label) ||
      match(r.parent_title) ||
      match(r.subject_name) ||
      match(r.teacher_name) ||
      match(r.parent_type) ||
      match(r.stream) ||
      match(String(r.grade || "")) ||
      match(String(r.year_start || "")) ||
      match(String(r.year_end || "")) ||
      match(String(r.session_no ?? ""))
    );
  }, [rows, q]);

  // Header pills
  const headerMeta = useMemo(() => {
    const arr = [];
    if (grade) arr.push({ icon: GraduationCap, label: `پۆل: ${grade}` });
    if (stream) arr.push({ icon: BookOpen, label: streamLabel(stream) });
    if (subject) arr.push({ icon: BookOpen, label: `بابەت: ${subject}` });
    return arr;
  }, [grade, stream, subject]);

  // --- YOUR REQUESTED VIEWER OPENER ---
  const openInViewer = (item) => {
    // Accepts flattened row item or raw record with common fields
    const raw =
      item?.url ||
      item?.pdf_url ||
      item?.file_url ||
      item?.image_url ||
      item?.thumb_url ||
      "";
    const url = toCU(raw);
    if (!url) return;
    const title = item?.item_label || item?.title || item?.name || item?.parent_title || "Viewer";
    const type = isPDF(url) ? "pdf" : isImage(url) ? "image" : isVideoFile(url) ? "video" : "file";
    navigate(`/viewer?u=${encodeURIComponent(url)}&t=${encodeURIComponent(title)}&type=${type}&back=${encodeURIComponent(backParam)}`);
  };

  return (
    <div dir="rtl" className="p-2.5 sm:p-4 space-y-3 sm:space-y-4">
      {/* Sticky header */}
      <div className="rounded-2xl sm:rounded-3xl border border-white/10 bg-gradient-to-br from-cyan-500/10 to-sky-500/5 p-2.5 sm:p-4 sticky top-2 z-10 backdrop-blur supports-[backdrop-filter]:bg-zinc-900/40">
        <div className="flex flex-col gap-2.5 sm:gap-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-white min-w-0">
              <ClipboardList className="w-5 h-5 text-cyan-300 shrink-0" />
              <div className="font-extrabold text-base sm:text-lg md:text-xl truncate">{headerTitle}</div>
              {meta.total ? <span className="text-[10.5px] sm:text-[11px] text-zinc-300 shrink-0">({meta.total})</span> : null}
            </div>
            <button
              onClick={() => navigate(-1)}
              className="inline-flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm px-2.5 sm:px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-sky-400/30"
              title="گەڕانەوە"
            >
              <ArrowRightCircle className="w-4 h-4" />
              گەڕانەوە
            </button>
          </div>

          {/* quick meta */}
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-[10.5px] sm:text-[11px] text-zinc-300">
            {headerMeta.map((m, i) => (
              <span key={i} className="px-2 py-0.5 rounded-xl bg-white/5 border border-white/10 inline-flex items-center gap-1">
                {m.icon ? <m.icon className="w-3 h-3" /> : null}
                {m.label}
              </span>
            ))}
          </div>

          {/* search */}
          <div className="flex items-center gap-2">
            <div className="relative w-full sm:w-[420px]">
              <input
                dir="rtl"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="گەڕان لە ناونیشان، مامۆستا، ساڵ، خولی، وانە..."
                className="w-full rounded-2xl bg-zinc-900/60 border border-white/10 text-white text-[13px] sm:text-sm px-9 sm:px-10 py-2 sm:py-2.5 outline-none focus:ring-2 focus:ring-sky-400/30"
              />
              <Search className="absolute left-2.5 sm:left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Errors */}
      {err && <div className="text-red-300 text-sm">{err}</div>}

      {/* Loading skeletons */}
      {loading && (
        <div className="space-y-2.5 sm:space-y-3">
          {Array.from({ length: 6 }).map((_, i) => <LoadingRow key={i} />)}
        </div>
      )}

      {/* Empty */}
      {!loading && filtered.length === 0 && (
        <div className="rounded-2xl border border-white/10 bg-zinc-900/60 p-5 sm:p-6 text-center text-zinc-300">
          هیچ پەڕەیەک نەدۆزرایەوە بەم فلتەرە.
        </div>
      )}

      {/* Vertical list of items */}
      {!loading && filtered.length > 0 && (
        <div className="space-y-2.5 sm:space-y-3">
          {filtered.map((it) => (
            <ItemRow
              key={it.row_key}
              item={it}
              onOpen={() => openInViewer(it)}
            />
          ))}
        </div>
      )}

      {/* Load more */}
      {!loading && meta.page < meta.last && (
        <div className="flex justify-center py-3 sm:py-4">
          <button
            onClick={loadMore}
            disabled={moreLoading}
            className="px-3.5 sm:px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-[13px] sm:text-sm border border-white/10 focus:outline-none focus:ring-2 focus:ring-sky-400/30"
          >
            {moreLoading ? (
              <span className="inline-flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" /> زیاتر باربکە
              </span>
            ) : (
              "زیاتر باربکە"
            )}
          </button>
        </div>
      )}
    </div>
  );

  /* -------- helpers (inside component for easy access) -------- */
  function flattenItems(list) {
    // transform paper groups -> simple rows
    const out = [];
    (list || []).forEach((p) => {
      const items = Array.isArray(p?.items) ? p.items : [];
      items.forEach((it, idx) => {
        out.push({
          row_key: `${p?.id || p?.title}-${it?.id || idx}`,
          url: it?.url || it?.pdf_url || it?.file_url || it?.image_url || it?.thumb_url,
          item_label: it?.label,
          year_start: it?.year_start ?? p?.year_start,
          year_end: it?.year_end ?? p?.year_end,
          term: it?.term ?? p?.term,
          session_no: it?.session_no,
          date: it?.date || p?.date || p?.created_at,
          grade: p?.grade,
          stream: p?.stream,
          subject_name: p?.subject?.name,
          teacher_name: p?.teacher?.full_name,
          parent_title: p?.title,
          parent_type: p?.type,
          created_at: p?.created_at,
        });
      });
    });
    return out;
  }
}
